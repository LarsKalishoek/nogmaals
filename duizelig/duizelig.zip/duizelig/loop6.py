totalsum = 0
number = 50
while totalsum < 1001:
    print(totalsum)
    totalsum = totalsum + number
    number = number + 1 
    
    