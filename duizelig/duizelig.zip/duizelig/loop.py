number = 30
while number > -1:
    print(number)
    number = number - 1 