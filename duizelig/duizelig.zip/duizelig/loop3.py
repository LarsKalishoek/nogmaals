count = 20
while count > 19 and count < 51:
    print(count)
    count = count + 2