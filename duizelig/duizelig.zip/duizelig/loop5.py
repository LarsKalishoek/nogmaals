Iteratie = 1
x = "dgffxn"
while x != "quit":
    print("Iteratie " + str(Iteratie))
    x = input("Type quit").lower()
    Iteratie = Iteratie + 1