from RobotArm import RobotArm

robotArm = RobotArm('exercise 7')
robotArm.speed = 3

# Jouw python instructies zet je vanaf hier:



# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()